package kanoo;

import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/ServletAdd")
public class ServletAdd extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // Get user inputs from the form
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone= request.getParameter("phone");
            String address= request.getParameter("address");
           

            // JDBC Connection details
            String jdbcUrl = "jdbc:mysql://localhost:3306/employee_db";
            String dbUsername = "root";
            String dbPassword = "root";

            try {
                // Load the JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish the database connection
                try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword)) {
                    // Insert employee data into the database
                    String sql = "INSERT INTO addbook (name,email,phone,address) VALUES (?,?,?,?)";
                    try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                        preparedStatement.setString(1, name);
                        preparedStatement.setString(2, email);
                        //address
                        preparedStatement.setString(3, phone);
                        preparedStatement.setString(4,address);
                       

                        int rowsInserted = preparedStatement.executeUpdate();

                        if (rowsInserted > 0) {
                        	 response.sendRedirect("successful.jsp");
                        } else {
                        	 response.sendRedirect("error.jsp");
                        }
                    }
                }
            } catch (Exception e) {
                out.println("<h2>Error: " + e.getMessage() + "</h2>");
            }
        }
    }
}
